package homework.recipeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Game on 2015-12-17.
 * 최근 본 레시피 DB
 */
public class LatelyDB extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Lately.db";
    public static final String LATELY_TABLE_NAME = "lately";
    public static final String LATELY_COLMN_ID = "id";
    public static final String LATELY_COLMN_RECIPE_ID = "recipe_id";
    public static final String LATELY_COLMN_NAME = "name";
    public static final String LATELY_COLMN_LINK = "link";

    public LatelyDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table lately" + "(id integer primary key, recipe_id integer, name text, link text)");
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS lately");
        onCreate(db);
    }

    // 데이터 삽입
    public boolean insertlately(String recipe_id, String name, String link ) {
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("recipe_id", recipe_id);
        contentValues.put("name", name);
        contentValues.put("link", link);

        db.insert("lately", null, contentValues);
        return true;
    }

    // 데이터 가져오기
    public Cursor getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from lately where id=" + id + "", null);
        return res;
    }

    // 데이터 삭제
    public Integer deletelately(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("lately", "id = ?", new String[] { Integer.toString(id)});
    }

    // 정렬
    public ArrayList getAlllately() {
        ArrayList array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from lately", null);
        res.moveToFirst();
        while(res.isAfterLast()==false){
            array_list.add(res.getString(res.getColumnIndex(LATELY_COLMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }
}

