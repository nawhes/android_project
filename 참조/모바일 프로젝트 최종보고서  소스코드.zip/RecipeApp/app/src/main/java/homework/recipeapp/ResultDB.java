package homework.recipeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Game on 2015-12-19.
 * 검색결과를 저장하는 DB
 */
public class ResultDB extends SQLiteOpenHelper{

    public static final String  DATABASE_NAME = "search.db";
    public static final String SEARCH_COLMN_NAME = "name";
    public static final String SEARCH_COLMN_RECIPE_ID ="recipe_id";

    public ResultDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table search" + "(id integer primary key, recipe_id integer, name text)");
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS search");
        onCreate(db);
    }

    // 데이터 삽입
    public boolean insertSearch(String recipe_id, String name) {
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("recipe_id", recipe_id);
        contentValues.put("name", name);

        db.insert("search", null, contentValues);
        return true;
    }

    // 데이터 가져오기
    public Cursor getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from search where id=" + id + "", null);
        return res;
    }

    // 정렬
    public ArrayList getAllSearch() {
        ArrayList array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from search", null);
        res.moveToFirst();
        while(res.isAfterLast()==false){
            array_list.add(res.getString(res.getColumnIndex(SEARCH_COLMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }

    // 데이터 삭제
    public Integer deleteSerch(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("search", "id = ?", new String[] { Integer.toString(id)});
    }
}
