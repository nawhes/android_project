package homework.recipeapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Game on 2015-12-16.
 * 요리이름, 즐겨찾기 여부, 레시피를 보여준다.
 */
public class Recipe extends ActionBarActivity {

    private WebView web;
    private FavoritesDB favoritesdb;
    private LatelyDB latelyDB;
    Cursor rs;
    int id=0;
    SQLiteDatabase db;
    DatabaseHelper dbhelper;
    int Value;
    CheckBox checkBox;

    public void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.recipe);

        dbhelper = new DatabaseHelper(this);
        db = dbhelper.getReadableDatabase();

        latelyDB = new LatelyDB(this);
        favoritesdb = new FavoritesDB(this);

        // 이전 액티비티에서 보낸 값을 이용하여 레시피 출력
        Bundle extras = getIntent().getExtras();
        if(extras!=null) {
            Value = extras.getInt("id");
            rs = dbhelper.getData(Value);
            id = Value;

            rs.moveToFirst();
            String n = rs.getString(rs.getColumnIndex(dbhelper.RECIPE_COLUMN_NAME));
            String l = rs.getString((rs.getColumnIndex(dbhelper.RECIPE_LINK)));
            String ri = rs.getString(rs.getColumnIndex(dbhelper.RECIPE_COLUMN_ID));

            TextView textView = (TextView) findViewById(R.id.recipetitle);
            textView.setText(n);

            //즐겨찾기에 등록된 레시피일 경우 즐겨찾기 란에 체크
            if(favoritesdb.checkRecipe(ri)){
                checkBox = (CheckBox)findViewById(R.id.cb1);
                checkBox.toggle();
            }


            // 최근 본 레시피에 저장
            if (latelyDB.insertlately(ri, n, l)) {
                Toast.makeText(getApplicationContext(), "최근 기록 저장", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "최근 기록 저장 실패", Toast.LENGTH_SHORT).show();
            }

            // 레시피를 웹리뷰어로 출력
            web = (WebView)findViewById(R.id.webview1);
            web.setWebViewClient(new TestBrower());
            web.getSettings().setLoadsImagesAutomatically(true);
            web.getSettings().setJavaScriptEnabled(true);
            web.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            web.loadUrl(l);
        }
    }

    // 즐겨찾기 체크박스에 관한 함수
    public void onCheckboxClick(View view){
        boolean checked = ((CheckBox) view).isChecked();
        rs= dbhelper.getData(Value);
        rs.moveToFirst();
        switch (view.getId()) {
            case R.id.cb1:
                if(checked){
                    // 체크 되었을 경우 FavoritesDB에 데이터 삽입
                    String ri=rs.getString(rs.getColumnIndex(dbhelper.RECIPE_COLUMN_ID));
                    String n=rs.getString(rs.getColumnIndex(dbhelper.RECIPE_COLUMN_NAME));
                    String l=rs.getString(rs.getColumnIndex(dbhelper.RECIPE_LINK));
                    if(favoritesdb.insertFavorites(ri,n,l)) {
                        Toast.makeText(getApplicationContext(), "즐겨찾기 저장", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"즐겨찾기 저장 실패", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    // 체크가 풀렸을 경우 FavoritesDB의 데이터 삭제
                    String ri=rs.getString(rs.getColumnIndex(dbhelper.RECIPE_COLUMN_ID));
                    int i= favoritesdb.delCheck(ri);
                    favoritesdb.deleteFavorites(i);
                    Toast.makeText(getApplicationContext(),"삭제 완료",Toast.LENGTH_SHORT).show();
                }
        }
    }

    private class TestBrower extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }
}
