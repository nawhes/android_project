package homework.recipeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Game on 2015-12-17.
 * 즐겨찾기 DB
 */
public class FavoritesDB extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Favorites.db";
    public static final String FAVORITES_TABLE_NAME = "favorites";
    public static final String FAVORITES_COLMN_ID = "id";
    public static final String FAVORITES_COLMN_RECIPE_ID = "recipe_id";
    public static final String FAVORITES_COLMN_NAME = "name";
    public static final String FAVORITES_COLMN_LINK = "link";

    public FavoritesDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table favorites" + "(id integer primary key, recipe_id integer, name text, link text)");
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS favorites");
        onCreate(db);
    }

    // 데이터 추가
    public boolean insertFavorites(String recipe_id, String name, String link ) {
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("recipe_id", recipe_id);
        contentValues.put("name", name);
        contentValues.put("link", link);

        db.insert("favorites", null, contentValues);
        return true;
    }

    // 데이터 가져오기
    public Cursor getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from favorites where id=" + id + "", null);
        return res;
    }

    // 데이터 삭제
    public Integer deleteFavorites(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("favorites", "id = ?", new String[] { Integer.toString(id)});
    }

    // 입력받은 id와 DB의 recipe_id를 비교
    public  Boolean checkRecipe(String id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from favorites", null);
        res.moveToFirst();
        String s;

        //값비교
        int ii = Integer.parseInt(id);
        while(res.isAfterLast()==false){
            s = res.getString(res.getColumnIndex(FAVORITES_COLMN_RECIPE_ID));
            int is = Integer.parseInt(s);
            if(ii==is){
                return true;
            }
            res.moveToNext();
        }
        return false;
    }

    // 삭제시, 입력받은 id와 같은 recipe_id를 가진 데이터의 id값을 출력
    public Integer delCheck(String id){
        String s;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from favorites", null);
        res.moveToFirst();

        //값비교
        int ii = Integer.parseInt(id);
        while(res.isAfterLast()==false){
            s = res.getString(res.getColumnIndex(FAVORITES_COLMN_RECIPE_ID));
            int is = Integer.parseInt(s);
            if(ii==is){
                return res.getInt(res.getColumnIndex(FAVORITES_COLMN_ID));
            }
            res.moveToNext();
        }
        return null;
    }

    // 정렬
    public ArrayList getAllFavorites() {
        ArrayList array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from favorites", null);
        res.moveToFirst();
        while(res.isAfterLast()==false){
            array_list.add(res.getString(res.getColumnIndex(FAVORITES_COLMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }
}
