package homework.recipeapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Game on 2015-12-10.
 * 최근 본 레시피에 대한 정보를 출력, 삭제
 */
public class Lately extends ActionBarActivity{

    private ListView listView;
    public LatelyDB latelyDB;
    ArrayAdapter mAdapter;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lately);

        latelyDB = new LatelyDB(this);
        ArrayList arrayList = latelyDB.getAlllately();

        mAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList);

        listView = (ListView) findViewById(R.id.latelylist);
        listView.setAdapter(mAdapter);

        // 리스트 선택시 해당하는 레시피의 정보를 전송, Recipe로 이동
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                int id = arg2 + 1;
                Bundle dataBundle = new Bundle();
                Cursor rs = latelyDB.getData(id);
                rs.moveToFirst();
                int value = rs.getInt(rs.getColumnIndex(latelyDB.LATELY_COLMN_RECIPE_ID));
                dataBundle.putInt("id", value);
                rs.close();
                Intent intent = new Intent(getApplicationContext(), homework.recipeapp.Recipe.class);
                intent.putExtras(dataBundle);
                startActivity(intent);
            }
        });

        registerForContextMenu(listView);
    }

    // 개별 삭제가 가능케 함

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("삭제하시겠습니까?");
        menu.add(0, 1, 0, "삭제");
        menu.add(0, 2, 0, "취소");
    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
        switch (item.getItemId()){
            case 1:
                AdapterView.AdapterContextMenuInfo menuInfo =
                        (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();

                int index = menuInfo.position;
                latelyDB.deletelately(index+1);
                onResume();
                closeContextMenu();
            case 2:
                closeContextMenu();
                default:
                    return  super.onContextItemSelected(item);
        }
    }

    // 리스트 초기화

    @Override
    protected void onResume(){
        super.onResume();
        mAdapter.clear();
        mAdapter.addAll(latelyDB.getAlllately());
        mAdapter.notifyDataSetChanged();
    }

    //데이터 전부 삭제
    public void onLatelyDelete(View target){
        db = latelyDB.getWritableDatabase();
        Cursor cursor =  db.rawQuery("select * from lately",null);
        cursor.moveToFirst();
        int num=1;
        while (cursor.isAfterLast()==false){

            latelyDB.deletelately(num);
            cursor.moveToNext();
            num++;
        }
        cursor.close();
        Toast.makeText(getApplicationContext(),"전부 삭제 완료", Toast.LENGTH_SHORT).show();
        onResume();
    }
}
