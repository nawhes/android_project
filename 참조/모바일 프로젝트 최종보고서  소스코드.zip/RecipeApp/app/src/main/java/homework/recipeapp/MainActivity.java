package homework.recipeapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// 처음 화면, 4개의 버튼과 각각 의 액티비티로 이동하는 함수들이 있다.


public class MainActivity extends ActionBarActivity{
    private static final int DIALOG_YES_NO_MESSAGE = 1;

    @Override
    protected Dialog onCreateDialog(int id){
        switch (id) {
            case DIALOG_YES_NO_MESSAGE:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("종료")
                        .setMessage("애플리케이션을 종료하시겠습니까?")
                        .setCancelable(false)
                        .setPositiveButton("Yes",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        MainActivity.this.finish();
                                    }
                                })
                        .setNegativeButton("No",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        dialog.cancel();
                                    }
                                });
                AlertDialog alert = builder.create();
                return  alert;

        }
        return  null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button b = (Button) findViewById(R.id.exit);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DIALOG_YES_NO_MESSAGE);
            }
        });
    }

    public void goFavorites(View target) {
        Intent intent = new Intent(getApplicationContext(),Favorites.class);
        startActivity(intent);
    }

    public void goLately(View target) {
        Intent intent = new Intent(getApplicationContext(),Lately.class);
        startActivity(intent);
    }

    public  void goSearch(View target) {
        Intent intent = new Intent(getApplicationContext(),Search.class);
        startActivity(intent);
    }
}
