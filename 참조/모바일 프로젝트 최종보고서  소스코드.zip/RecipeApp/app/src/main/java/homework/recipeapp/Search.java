package homework.recipeapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Game on 2015-12-11.
 * 검색을 하고 검색한 데이터를 ResultDB에 저장, ResultDB를 이용하여 Recipe로 이동
 */
public class Search extends ActionBarActivity{

    ListView listView;  // 검색된 레시피가 나열되는 리스트뷰
    public SQLiteDatabase db;   // ResultDB용
    public SQLiteDatabase db2;  // DatabaseHelper용

    ArrayAdapter mAdapter;
    DatabaseHelper mHelper;

    String[] str= new String[3];    // 재료 입력용 문자열배열
    String mat;

    int num=0;  // 재료 입력 순서 변수

    ResultDB rdb;

    // 검색시 사용하는 체크박스
    CheckBox c1;
    CheckBox c2;
    CheckBox c3;
    CheckBox c4;
    CheckBox c5;
    CheckBox c6;
    CheckBox c7;
    CheckBox c8;
    CheckBox c9;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);

        // 재료 입력값 초기화
        num=0;
        for(int i=0;i<3; i++){
            str[i]=null;
        }
        rdb = new ResultDB(this);
        db=rdb.getWritableDatabase();

        c1= (CheckBox)findViewById(R.id.dish);
        c2= (CheckBox)findViewById(R.id.sub_dish);
        c3= (CheckBox)findViewById(R.id.dessert);
        c4= (CheckBox)findViewById(R.id.easy);
        c5= (CheckBox)findViewById(R.id.nomal);
        c6= (CheckBox)findViewById(R.id.hard);
        c7= (CheckBox)findViewById(R.id.shorttime);
        c8= (CheckBox)findViewById(R.id.nomaltime);
        c9= (CheckBox)findViewById(R.id.longtime);

        // ResultDB를 리스트뷰에 출력
        ArrayList arrayList =rdb.getAllSearch();

        mAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,arrayList);

        listView = (ListView) findViewById(R.id.searchlist);
        listView.setAdapter(mAdapter);


        // 리스트 선택시 해당하는 레시피의 정보를 전송, Recipe로 이동
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                int id = arg2 + 1;
                Bundle dataBundle = new Bundle();
                Cursor rs = rdb.getData(id);
                rs.moveToFirst();
                int value = rs.getInt(rs.getColumnIndex(rdb.SEARCH_COLMN_RECIPE_ID));
                dataBundle.putInt("id", value);
                rs.close();
                Intent intent = new Intent(getApplicationContext(), homework.recipeapp.Recipe.class);
                intent.putExtras(dataBundle);
                startActivity(intent);

            }
        });


        mat="";

        // 매번 리스트뷰 초기화
        AllDelete();
        onResume();

    }

    // '갱신'버튼을 누르면 작동
    public void onUp(View target){

        // 입력한 값 읽어오기
        TextView textView= (TextView)findViewById(R.id.editext);
        String s= textView.getText().toString();

        // 재료를 입력받는다.
        // 입력받은 재료가 없으면 입력을 받지 않는다.
        if(s.getBytes().length > 0){
            // 입력받는 재료는 최대 3개 까지 가능
            if(num<3){
                str[num]=s;
                Toast.makeText(getApplicationContext(),(num+1)+"번째 재료 입력 완료: "+ str[num],Toast.LENGTH_SHORT).show();
                num++;

                //검색창 하단에 입력받은 재료 출력
                mat+=s+" ";
                TextView matText= (TextView)findViewById(R.id.mat);
                matText.setText(mat);
                textView.setText(null); //검색창 초기화

                searchDB(); //검색을 시작한다.
            }
            else{
                Toast.makeText(getApplicationContext(),
                        "최대 3개 까지 입력 가능합니다!",
                        Toast.LENGTH_SHORT).show();
            }
        }else{
            // 입력받은 값이 없고 입력받은 재료조차 없으면
            if(str[0]==null) {
                Toast.makeText(getApplicationContext(),
                        "재료가 없습니다. 재료를 입력해주세요",
                        Toast.LENGTH_SHORT).show();
            }
            else{
                searchDB(); // 재료가 있는 상태면 검색을 실행시킨다.
                //체크박스 체크변경여부를 위한 부분
            }
        }
    }

    // 검색 함수
    public void searchDB(){

        mHelper= new DatabaseHelper(this);
        db2 = mHelper.getReadableDatabase();
        Cursor cursor;
        String s;

        /*
        입력된 재료 비교 :
        입력받은 재료를 Recipe.db에 있는 값과 비교하여 ResultDB에 저장한다.

        우선순위 순으로 DB에 저장한다.
        첫번째의 경우 - 1, 2, 3 번째 순으로 입력비교
        두번재의 경우 - 12, 13, 21, 23, 31, 32 순으로 입력비교
        세번째의 경우 - 123, 132, 213, 231, 312, 321 순으로 입력비교

        입력받은 재료명과 레시피의 재료명이 같다면 해당 Cursor를 onCheckbox()로 보내
        체크여부를 확인하여 조건에 충족 여부를 출력한다.
         */
        if(str[0]!=null){
            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            AllDelete();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1));
                if(str[0].equals(s)){
                    if(onCheckbox(cursor)) {
                        rdb.insertSearch(
                                cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                        );
                    }
                }
                cursor.moveToNext();
            }
            onResume();
            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2));
                if(str[0].equals(s)){
                    if(onCheckbox(cursor)) {
                        rdb.insertSearch(
                                cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                        );
                    }
                }
                cursor.moveToNext();
            }

            onResume();
            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3));
                if(str[0].equals(s)){
                    if(onCheckbox(cursor)) {
                        rdb.insertSearch(
                                cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                        );
                    }
                }
                cursor.moveToNext();
            }
            cursor.close();
            onResume();
        }
        if(str[1]!=null){

            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            AllDelete();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2));
                if(str[1].equals(s)){
                    if(str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1)))) {
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3));
                if(str[1].equals(s)){
                    if(str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1)))) {
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                cursor.moveToNext();
            }
            onResume();

            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1));
                if(str[1].equals(s)){
                    if(str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2)))) {
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3));
                if(str[1].equals(s)){
                    if(str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2)))) {
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                cursor.moveToNext();
            }
            onResume();

            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1));
                if(str[1].equals(s)){
                    if(str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3)))) {
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2));
                if(str[1].equals(s)){
                    if(str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3)))) {
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                cursor.moveToNext();
            }
            onResume();
            cursor.close();
        }
        if(str[2]!=null){
            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            AllDelete();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3));
                if(str[2].equals(s)){
                    if((str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1))))&&
                            (str[1].equals((cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2)))))){
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2));
                if(str[2].equals(s)){
                    if((str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1))))&&
                            (str[1].equals((cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3)))))){
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                cursor.moveToNext();
            }
            cursor = db2.rawQuery("select * from Recipe",null);
            cursor.moveToFirst();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3));
                if(str[2].equals(s)){
                    if((str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2))))&&
                            (str[1].equals((cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1)))))){
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1));
                if(str[2].equals(s)){
                    if((str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2))))&&
                            (str[1].equals((cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3)))))){
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                cursor.moveToNext();
            }
            cursor = db2.rawQuery("select * from Recipe",null);
                cursor.moveToFirst();
            while(cursor.isAfterLast()==false){
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2));
                if(str[2].equals(s)){
                    if((str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3))))&&
                            (str[1].equals((cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1)))))){
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                s=cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_1));
                if(str[2].equals(s)){
                    if((str[0].equals(cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_3))))&&
                            (str[1].equals((cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_MATERIAL_2)))))){
                        if(onCheckbox(cursor)) {
                            rdb.insertSearch(
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_ID)),
                                    cursor.getString(cursor.getColumnIndex(mHelper.RECIPE_COLUMN_NAME))
                            );
                        }
                    }
                }
                cursor.moveToNext();
            }
            onResume();
            cursor.close();
        }

    }

    // 체크박스 체크여부
    public boolean onCheckbox(Cursor cs){

        //체크 여부 & 조건 충족 여부
        boolean cp=false;
        boolean cg1=false;
        boolean cg2=false;
        boolean cg3=false;

        mHelper= new DatabaseHelper(this);
        db2 = mHelper.getReadableDatabase();
        String s;

        /*
        123, 456, 789 를 각각 한 그륩으로 지정하여 체크 여부를 확인,
        그륩의 3개의 체크박스중 하나라도 체크가 안되있으면 통과
         */
        if((c1.isChecked())||(c2.isChecked())||(c3.isChecked())){
            s= cs.getString(cs.getColumnIndex(mHelper.RECIPE_TYPE));
            if(c1.isChecked()){
                if (s.equals("dish")){
                    cg1=true;
                }
            }
            if(c2.isChecked()){
                if (s.equals("sub")){
                    cg1=true;
                }
            }
            if(c3.isChecked()){
                if(s.equals("dessert")){
                    cg1=true;
                }
            }
            cp=true;
        }
        else{
            cg1=true;
        }
        if((c4.isChecked())||(c5.isChecked())||(c6.isChecked())){
            s= cs.getString(cs.getColumnIndex(mHelper.RECIPE_LEVEL));
            if(c4.isChecked()){
                if (s.equals("easy")){
                    cg2=true;
                }
            }
            if(c5.isChecked()){
                if (s.equals("normal")){
                    cg2=true;
                }
            }
            if(c6.isChecked()){
                if(s.equals("hard")){
                    cg2=true;
                }
            }
            cp=true;
        }else{
            cg2=true;
        }
        if((c7.isChecked())||(c8.isChecked())||(c9.isChecked())){
            s= cs.getString(cs.getColumnIndex(mHelper.RECIPE_TIME));
            if(c7.isChecked()){
                if (s.equals("short")){
                    cg3=true;
                }
            }
            if(c8.isChecked()){
                if (s.equals("normal")){
                    cg3=true;
                }
            }
            if(c9.isChecked()){
                if(s.equals("long")){
                    cg3=true;
                }
            }
            cp=true;
        }else{
            cg3=true;
        }

        if(!cp){
            return true;
        }
        if((cg1)&&(cg2)&&(cg3)){
            return true;
        }
        return false;
    }

    /*
    초기화버튼의 동작 함수
    체크박스의 체크, ResultDB의 데이터, 검색창을 전부 지운다.
    ResultDB에 데이터가 없으므로 리스트도 초기화된다.
     */
    public void onClear(View target){
        num=0;
        while(num<3) {
            str[num]=null;
            num++;
        }
        num=0;
        mat="";
        TextView matText= (TextView)findViewById(R.id.mat);
        matText.setText(mat);
        TextView textView= (TextView)findViewById(R.id.editext);
        textView.setText(null);
        InputMethodManager im = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(textView.getWindowToken(), 0);
        c1.setChecked(false);
        c2.setChecked(false);
        c3.setChecked(false);
        c4.setChecked(false);
        c5.setChecked(false);
        c6.setChecked(false);
        c7.setChecked(false);
        c8.setChecked(false);
        c9.setChecked(false);
        AllDelete();
        onResume();
        Toast.makeText(getApplicationContext(),"초기화완료",Toast.LENGTH_SHORT).show();
    }

    // 리스트뷰를 새로 갱신한다.
    protected void onResume(){
        super.onResume();
        mAdapter.clear();
        mAdapter.addAll(rdb.getAllSearch());
        mAdapter.notifyDataSetChanged();
    }

    // ResultDB에 있는 데이터를 지운다.
    public void AllDelete(){
        Cursor cursor =  db.rawQuery("select * from search", null);
        cursor.moveToFirst();
        int num=1;
        while (cursor.isAfterLast()==false){

            rdb.deleteSerch(num);
            cursor.moveToNext();
            num++;
        }
        Toast.makeText(getApplicationContext(), "전부 삭제 완료", Toast.LENGTH_SHORT);
        onResume();
    }
}
