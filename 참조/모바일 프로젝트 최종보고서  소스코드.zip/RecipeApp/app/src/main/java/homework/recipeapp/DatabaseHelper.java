package homework.recipeapp;

import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String ROOT_DIR = "/data/data/homework.recipeapp/databases/";
    private static final String DATABASE_NAME = "Recipe.db";
    private static final int SCHEMA_VERSION = 1;

    public static final String RECIPE_COLUMN_ID = "id";
    public static final String RECIPE_COLUMN_NAME = "name";
    public static final String RECIPE_MATERIAL_1 = "material1";
    public static final String RECIPE_MATERIAL_2 = "material2";
    public static final String RECIPE_MATERIAL_3 = "material3";
    public static final String RECIPE_TYPE = "type";
    public static final String RECIPE_LEVEL = "level";
    public static final String RECIPE_TIME = "time";
    public static final String RECIPE_LINK = "link";


    public DatabaseHelper(Context context)    {
        super(context, DATABASE_NAME, null, SCHEMA_VERSION);
        setDB(context);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}


    /*
    파일 입출력과 AssetManager를 통하여 assets에 저장된 DB를 읽어내고 복사하여
    /database/ 폴더에 저장, 그리고 그 DB를 SQLiteDatabase로 이용할 수 있게 함
     */
    public static void setDB(Context ctx) {
        File folder = new File(ROOT_DIR);
        if(folder.exists()) {
        } else {
            folder.mkdirs();
        }
        AssetManager assetManager = ctx.getResources().getAssets();
        File outfile = new File(ROOT_DIR+"Recipe.db");
        InputStream is = null;
        FileOutputStream fo = null;
        long filesize = 0;
        try {
            is = assetManager.open("Recipe.db", AssetManager.ACCESS_BUFFER);
            filesize = is.available();
            if (outfile.length() <= 0) {
                byte[] tempdata = new byte[(int) filesize];
                is.read(tempdata);
                is.close();
                outfile.createNewFile();
                fo = new FileOutputStream(outfile);
                fo.write(tempdata);
                fo.close();
            } else {}
        } catch (IOException e) {}
    }

    // 정렬
    public ArrayList getAllRecipe(){
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from Recipe",null);
        res.moveToFirst();
        while(res.isAfterLast()==false){
            arrayList.add(res.getString(res.getColumnIndex("name")));
            res.moveToNext();
        }
        return arrayList;
    }

    // 데이터 가져오기
    public Cursor getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from Recipe where id=" + id + "",null);
        return res;
    }
}
